def conecta(ssid, senha):#Conexão automatizada de rede
    #Bibliotecas
    import network
    from time import sleep
    #=====================
#station.scan() para localizar as redes disponíveis
    station = network.WLAN(network.STA_IF)#Configurar o recurso de hardware do esp32
    station.active(True)#Inicializar o modo estação
    station.connect("SRC","Src197272")# Rede escolhida para conectar ao esp32
    for t in range(30): # Realizar várias tentativas de conexão
        if station.isconnected():# Quebra o laço caso seja conectada.
            break
        sleep(0.1)
    return station # Volte para station