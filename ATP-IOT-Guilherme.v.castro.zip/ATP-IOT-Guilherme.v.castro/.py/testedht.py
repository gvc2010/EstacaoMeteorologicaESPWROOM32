#Bibliotecas
import dht 
import machine
from time import sleep
#=====================


d = dht.DHT11(machine.Pin(4)) #Acesso ao dht11 , conexão com o pino 4

while True:
    d.measure() # Realizar medida 
    print(f'Temperatura:{d.temperature()} \nUmidade:{d.humidity}') # Temperature para temperatura e Humidity para umidade
    sleep(5)
