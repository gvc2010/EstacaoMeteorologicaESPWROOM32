import machine #Biblioteca 
from time import sleep #Biblioteca
#Sleep() tempo que liga e desliga após o acionamento de relé

r = machine.Pin(2, machine.Pin.OUT)# Recebe objeto tratado do pino GPIO

while True: 
    r.value(1)# 1 liga e aciona o relé
    sleep(2) 
    r.value(0)# 2 Desliga o relé
    sleep(2)

