#Bibliotecas
import urequests
from wifilib import conecta#(função criada)
#==========================



print("conectando...")
station = conecta("SRC", "Src197272")

if not station.isconnected():#Verificar se a rede está conectada
    print('Não foi possível conectar.')

else:
    print("Conectado com sucesso!")
    print("Acessando a página.")
    resposta = urequests.get("https://pt.wikipedia.org/wiki/Monza") # Para acessar o site / Body HTML
    print("Página acessada")
    print(resposta)
    station.disconnect()#Desconectar da rede
        
